import pandas as pd
import jax.numpy as jnp


def load_antikythera(fname):
    # import data from file
    file = fname
    
    # read csv directly from github
    df = pd.read_csv(file)

    # just extract ID, X,Y values
    data_col = df[["Section ID", "Mean(X)", "Mean(Y)"]]

    jax_array = jnp.array(data_col)

    # First index for ID, second index for X (1) or Y (2)
    X = jax_array[:,1]
    Y = jax_array[:,2]

    data = [X,Y]

    return data